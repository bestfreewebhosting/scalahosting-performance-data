#!/usr/bin/env bash
# Measure DNS, connect, TLS and TTFB for a URL.
# Usage: ./scripts/ttfb-check.sh https://example.com [runs]
set -euo pipefail

URL="${1:?Usage: $0 <url> [runs]}"
RUNS="${2:-5}"

echo "run,dns_ms,connect_ms,tls_ms,ttfb_ms,total_ms,http_code"
for i in $(seq 1 "$RUNS"); do
  curl -o /dev/null -s -L \
    -w "${i},%{time_namelookup},%{time_connect},%{time_appconnect},%{time_starttransfer},%{time_total},%{http_code}\n" \
    "$URL" | awk -F, 'BEGIN{OFS=","} {print $1,$2*1000,$3*1000,$4*1000,$5*1000,$6*1000,$7}'
  sleep 1
done
