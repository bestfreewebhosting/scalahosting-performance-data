#!/usr/bin/env bash
# Print one CSV line: timestamp, HTTP status, response time in ms.
# Usage (cron): */5 * * * * /path/to/uptime-check.sh https://example.com >> data/uptime-log.csv
set -uo pipefail

URL="${1:?Usage: $0 <url>}"
TS="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

OUT="$(curl -o /dev/null -s -L --max-time 15 -w '%{http_code},%{time_total}' "$URL" || echo '000,0')"
CODE="${OUT%%,*}"
TIME_S="${OUT##*,}"
TIME_MS="$(awk -v t="$TIME_S" 'BEGIN{printf "%d", t*1000}')"

echo "${TS},${CODE},${TIME_MS}"
