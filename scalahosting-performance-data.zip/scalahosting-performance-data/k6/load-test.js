import http from 'k6/http';
import { check, sleep } from 'k6';

// Usage: TARGET_URL=https://example.com k6 run k6/load-test.js
const TARGET_URL = __ENV.TARGET_URL || 'https://example.com';

export const options = {
  stages: [
    { duration: '1m', target: 20 }, // ramp up
    { duration: '3m', target: 20 }, // hold
    { duration: '1m', target: 0 },  // ramp down
  ],
  thresholds: {
    http_req_failed: ['rate<0.01'],      // fewer than 1% failed requests
    http_req_duration: ['p(95)<1000'],   // 95% of requests under 1 second
  },
};

export default function () {
  const res = http.get(TARGET_URL);
  check(res, {
    'status is 200': (r) => r.status === 200,
  });
  sleep(1);
}
